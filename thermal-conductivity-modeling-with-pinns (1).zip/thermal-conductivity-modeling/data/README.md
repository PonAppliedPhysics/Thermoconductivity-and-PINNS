# Data Folder

Place the raw experimental Excel files for the notebook in this folder.

## Expected filenames

- `run_1.xlsx`
- `run_2.xlsx`
- `run_3.xlsx`
- `Run_4.xlsx`

## Notes

- The notebook automatically handles common duplicate-upload filenames such as `run_2(1).xlsx`.
- The working phase start rows are defined in the notebook:
  - `run1` → row `3622`
  - `run2` → row `4270`
  - `run3` → row `3282`
  - `run4` → row `3962`
- The data are expected to contain 11 thermocouple columns and no header row.
